#!/usr/bin/env python3
"""
Script to update all form.samakreatif.com links to konsultasi.html
with proper URL parameters based on context
"""

import os
import re
from pathlib import Path

# Define service configurations
service_configs = {
    'social-media-management.html': {
        'service': 'Social Media Management',
        'packages': ['Paket Basic', 'Paket Business', 'Paket Enterprise']
    },
    'instagram-shopping-activate.html': {
        'service': 'Instagram Shopping Activate',
        'packages': ['Paket Starter', 'Paket Business', 'Paket Enterprise']
    },
    'visual-design.html': {
        'service': 'Visual Design',
        'packages': ['Paket Basic', 'Paket Professional']
    },
    'website-development.html': {
        'service': 'Website Development',
        'packages': ['Paket Landing Page', 'Paket Company Profile', 'Paket E-Commerce']
    },
    'digital-ads.html': {
        'service': 'Digital Ads',
        'packages': ['Paket Starter', 'Paket Growth', 'Paket Scale']
    }
}

def update_file(filepath, filename):
    """Update form links in a single HTML file"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        original_content = content
        updates_made = 0

        # Check if this is a service page
        if filename in service_configs:
            config = service_configs[filename]
            service_name = config['service']
            packages = config['packages']

            # Pattern 1: Replace ALL form.samakreatif.com links with service parameter
            # This catches generic CTA buttons
            pattern1 = r'href="https://form\.samakreatif\.com/partnership-with-us/[^"]*"'
            replacement1 = f'href="konsultasi.html?service={service_name}&source={filename.replace(".html", "_page")}"'
            content = re.sub(pattern1, replacement1, content)
            updates_made += len(re.findall(pattern1, original_content))

            # Pattern 2: Replace any remaining form links (catch-all for service pages)
            pattern2 = r'href="https://form\.samakreatif\.com/[^"]*"'
            replacement2 = f'href="konsultasi.html?service={service_name}&source={filename.replace(".html", "_page")}"'
            content = re.sub(pattern2, replacement2, content)

        else:
            # For non-service pages, just replace with source parameter
            pattern = r'href="https://form\.samakreatif\.com/[^"]*"'
            source_name = filename.replace('.html', '_page')
            replacement = f'href="konsultasi.html?source={source_name}"'
            content = re.sub(pattern, replacement, content)
            updates_made += len(re.findall(pattern, original_content))

        # Only write if changes were made
        if content != original_content:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True, updates_made
        else:
            return False, 0

    except Exception as e:
        print(f"❌ Error processing {filename}: {e}")
        return False, 0

def main():
    """Main function to process all HTML files"""
    html_files = [
        'index.html',
        'about.html',
        'contact.html',
        'work.html',
        'team.html',
        'project-details.html',
        'social-media-management.html',
        'instagram-shopping-activate.html',
        'visual-design.html',
        'website-development.html',
        'digital-ads.html',
        'faq-igshop.html',
        'faq-webdev.html',
        'under-construction.html',
        'error.html'
    ]

    print("🔄 Starting form link updates...\n")

    total_updates = 0
    files_updated = 0

    for filename in html_files:
        filepath = f"/Users/mac/VSC Project/SAMA Kreatif HTML/{filename}"

        if os.path.exists(filepath):
            updated, count = update_file(filepath, filename)
            if updated:
                files_updated += 1
                total_updates += count
                print(f"✅ Updated {filename}: {count} link(s) changed")
            else:
                print(f"⏭️  Skipped {filename}: No form links found")
        else:
            print(f"⚠️  File not found: {filename}")

    print(f"\n📊 Summary:")
    print(f"   Files updated: {files_updated}")
    print(f"   Total links updated: {total_updates}")
    print(f"\n✨ Done! All form links have been updated.")

if __name__ == "__main__":
    main()
